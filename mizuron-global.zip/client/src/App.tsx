import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import { useEffect } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

// Pages
import Home from "./pages/Home";
import About from "./pages/About";
import Solutions from "./pages/Solutions";
import Industries from "./pages/Industries";
import SustainabilityLab from "./pages/SustainabilityLab";
import Logistics from "./pages/Logistics";
import Contact from "./pages/Contact";

// Product pages
import Vermicompost from "./pages/products/Vermicompost";
import Biochar from "./pages/products/Biochar";
import CoffeePage from "./pages/products/Coffee";
import AgriProducts from "./pages/products/AgriProducts";

// Products index page (redirect to vermicompost or show overview)
import ProductsIndex from "./pages/products/ProductsIndex";

// Scroll to top on route change
function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location]);
  return null;
}

function Router() {
  return (
    <>
      <ScrollToTop />
      <Navbar />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/solutions" component={Solutions} />
          <Route path="/industries" component={Industries} />
          <Route path="/sustainability-lab" component={SustainabilityLab} />
          <Route path="/logistics" component={Logistics} />
          <Route path="/contact" component={Contact} />
          {/* Product routes */}
          <Route path="/products" component={ProductsIndex} />
          <Route path="/products/vermicompost" component={Vermicompost} />
          <Route path="/products/biochar" component={Biochar} />
          <Route path="/products/coffee" component={CoffeePage} />
          <Route path="/products/agri" component={AgriProducts} />
          {/* Fallback */}
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: "oklch(17% 0.009 200)",
                border: "1px solid oklch(26% 0.009 200)",
                color: "oklch(90% 0.003 200)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
